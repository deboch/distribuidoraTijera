<?php

include("../controlador/controlador_cliente.php");
?>
<!DOCTYPE html>
<html>
<?php
include("../head.php");
?>
<body>
    <h2>Distribuidora Tijera!</h2>
    <h4>Clientes</h4>
    <button type="button" class="btn btn-success">Agregar</button>
 
    <div class="table-responsive">
            <table class="table table-striped" id="dataTable" width="100%" cellspacing="0">
                <thead>
                <tr>
                    <th>Numero</th>
                    <th>Cliente</th>
                    <th>Direccion</th>
                    <th>Localidad</th>
                    <th>Telefono</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php
                    foreach ($clientes as $cliente){
                        echo "<tr>
                             <td>".$cliente['numero']."</td>                             
                             <td>".$cliente['nombre']."</td>
                             <td>".$cliente['direccion']."</td>
                             <td>".$cliente['localidad']."</td>
                             <td>".$cliente['telefono']."</td>  
                             <td><a href='../controlador/controlador_cliente.php?numero=".$cliente['numero']."'>Eliminar</a></td>
                             <td><a href=''>Modificar</a></td>                           
                         </tr>";
                    }
                ?>
                </tbody>
            </table>


</body>
<footer>
</footer>
</html>