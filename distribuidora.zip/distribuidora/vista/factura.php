
<!DOCTYPE html>
<html>
<?php
include("../head.php");
?>
<body>
    <div class="row">
        <div class="col-md-12">
            <h2>Distribuidora Tijera</h2>
            <h4>Factura<h4>
        </div>
    </div>  
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4">
                    <label class="form-control">Cliente</label>
                    <input class="form-control" type="text" placeholder="Ingrese cliente">
                </div>
                <div class="col-md-4">   
                    <label class="form-control">Teléfono</label>
                    <input class="form-control" type="text" placeholder="Ingrese teléfono">
                </div>
                <div class="col-md-4">
                    <label class="form-control">Fecha</label>
                    <input class="form-control" type="date" placeholder="Ingrese fecha">
                </div>
            </div>
                      
        </div> 
    </div>
    <br>
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Articulo</th>
      <th scope="col">Tipo</th>
      <th scope="col">Cantidad</th>
      <th scope="col">Descripción</th>
      <th scope="col">Precio Unit.</th>
      <th scope="col">Total</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td><a href="" >Eliminar</a></td>
    </tr>
    
  </tbody>
</table>
</body>
<footer></footer>
</html>