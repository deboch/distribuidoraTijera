<?php

include("../controlador/controlador_articulos.php");

?>
<!DOCTYPE html>
<html>
<?php
include("../head.php");
?>
<body>
    <h2>Lista</h2>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="card-header py-3">
                <form method="get" action="../controlador/controlador_lista.php">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Articulo</label>
                                <input class="form-control col-4" type="text" placeholder="Ingrese articulo" id="cod_art" name="cod_art">
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <button class="btn btn-primary col-2 offset-5" name="submit" type="submit">Buscar</button>
                    </div>
                </form>
        </div>
    </div>
    <div class="row">
    <button type="button" class="btn btn-success">Agregar</button>
    </div>
   

    <div class="table-responsive">
            <table class="table table-striped" id="dataTable" width="100%" cellspacing="0">
                <thead>
                <tr>
                    <th>Articulo</th>
                    <th>Descripcion</th>
                    <th>Eje</th>
                    <th>Aloj.</th>
                    <th>Esp.</th>
                    <th>Form.</th>
                    <th>Giro</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php
                    foreach ($articulos as $articulo){
                        echo "<tr>
                             <td>".$articulo['codigo']."</td>                             
                             <td>".$articulo['descripcion']."</td>
                             <td>".$articulo['eje']."</td>
                             <td>".$articulo['aloj.']."</td>
                             <td>".$articulo['esp.']."</td>
                             <td>".$articulo['form.']."</td>  
                             <td>".$articulo['giro']."</td>
                             <td><a href=''></a></td>
                             <td><a href=''></a></td>                           
                         </tr>";
                    }
                ?>
                </tbody>
            </table></body>
<footer></footer>
</html>