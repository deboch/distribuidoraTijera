<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
    <h1>Bienvenido Distribuidora Tijera!</h1>
    <a class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2" href="vista/factura.php">Factura</a>
    <a class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2" href="vista/articulos.php">Articulos</a>
    <a class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2" href="vista/precios.php">Precios</a>
    <a class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2" href="vista/clientes.php">Clientes</a>
    
</body>
<footer>
</footer>
</html>