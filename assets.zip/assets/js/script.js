function agregarFila(){
  document.getElementById("mitabla").insertRow(-1).innerHTML = " <td scope='row'><input class='form-control' type='text' maxlength='6'></td>
			  <td>
				  <select class='form-control'>
					  <option value='0'>G</option>
					  <option value='1'>S</option>
					  <option value='2'>B</option>
					  <option value='3'>V</option>
				  </select>
			  </td>
			  <td>
				<input class='form-control' type='number' min='1'>
			  </td>
			  <td>
				<input class='form-control' type='text'>
			  </td>
			  <td>
				<input class='form-control' type='text' placeholder='$'>
			  </td>
			  <td>
				<input class='form-control' type='text' placeholder='$'>
			  </td>
			  <td><a href='' >Eliminar</a></td>
			</tr>";
}
